#!/usr/bin/env python3
"""
evaluate.py -- Harness de Avaliacao End-to-End

Corre o pipeline completo sobre um dataset de validacao e calcula
6 metricas de qualidade automaticamente.

Uso:
    python evaluate.py --data events_validation.csv --output evaluation_report.json

Metricas calculadas:
  1. Consistencia      -- % trajectórias sem sobreposicao temporal (alvo: 100%)
  2. Cobertura         -- % eventos atribuidos a alguma trajectória
  3. Completude        -- % trajectórias com inicio Z_E e fim Z_E/Z_CK
  4. Detecao anomalias -- % anomalias injetadas identificadas nos insights
  5. Precisao numerica -- % valores numericos nos insights verificaveis nos dados
  6. Ausencia alucinacao -- % afirmacoes factuais no report verificaveis no metrics.json

O harness nao esta optimizado para o dataset de treino:
  - Usa os mesmos algoritmos genericos do pipeline (stitcher, analytics, insights)
  - Temperatura 0 para reproducibilidade
  - Sem hardcoding de valores do dataset de treino
"""

import argparse
import json
import logging
import re
import sys
import tempfile
from pathlib import Path
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("evaluate")

# ── Paths ─────────────────────────────────────────────────────────────────────

def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "src" / "stitcher.py").exists():
            return path
    return Path.cwd()


ROOT = _find_root()
sys.path.insert(0, str(ROOT / "src"))

ENTRY_ZONES    = {"Z_E1", "Z_E2"}
EXIT_ZONES     = {"Z_E1", "Z_E2", "Z_CK"}
SIGMA_THRESHOLD = 2.0   # mesmo threshold do analytics.py


# ── Correr pipeline ───────────────────────────────────────────────────────────

def run_pipeline(data_path: str, tmp_dir: Path) -> dict:
    """
    Corre o pipeline completo sobre o dataset de validacao.
    Usa ficheiros temporarios para nao sobrescrever os outputs de treino.
    Devolve dicionario com caminhos dos outputs e os dados carregados.
    """
    journeys_path = tmp_dir / "journeys_val.csv"
    metrics_path  = tmp_dir / "metrics_val.json"
    insights_path = tmp_dir / "insights_val.json"
    report_path   = tmp_dir / "report_val.md"

    log.info("── Fase 1: Stitcher ────────────────────────────────────")
    from stitcher import run as run_stitcher
    journeys_df = run_stitcher(data_path, str(journeys_path))

    log.info("── Fase 2: Analytics ───────────────────────────────────")
    from analytics import run as run_analytics
    metrics = run_analytics(str(journeys_path), str(metrics_path))

    log.info("── Fase 3: Insights ────────────────────────────────────")
    try:
        from insights import run as run_insights
        insights = run_insights(str(metrics_path), str(insights_path), strategy="B")
    except Exception as e:
        log.warning("Insights nao gerados (LLM indisponivel?): %s", e)
        insights = {"insights": [], "resumo_executivo": ""}
        with open(insights_path, "w") as f:
            json.dump(insights, f)

    log.info("── Fase 4: Report ──────────────────────────────────────")
    try:
        from report import run as run_report
        report_text = run_report(str(insights_path), str(report_path))
    except Exception as e:
        log.warning("Report nao gerado: %s", e)
        report_text = ""

    # Carregar eventos originais para calcular cobertura
    events_df = pd.read_csv(data_path, dtype=str)
    events_df.columns = [c.strip().lower() for c in events_df.columns]

    return {
        "journeys_df":  journeys_df,
        "events_df":    events_df,
        "metrics":      metrics,
        "insights":     insights,
        "report_text":  report_text,
        "metrics_path": metrics_path,
    }


# ── Metrica 1: Consistencia ───────────────────────────────────────────────────

def calc_consistencia(journeys_df: pd.DataFrame) -> dict:
    """
    % de trajectórias onde nenhuma pessoa esta em duas zonas em simultaneo.
    Uma violacao = entry de zona B antes do exit de zona A, na mesma trajectória.
    Alvo: 100%.
    """
    if journeys_df.empty:
        return {"value": 0.0, "violations": 0, "total_trajectories": 0, "passed": False}

    j = journeys_df.copy()
    j["entry_dt"] = pd.to_datetime(j["entry_time"])
    j["exit_dt"]  = pd.to_datetime(j["exit_time"])

    violations = 0
    total      = j["person_id"].nunique()

    for _, grp in j.groupby("person_id"):
        grp = grp.sort_values("entry_dt").reset_index(drop=True)
        for i in range(1, len(grp)):
            if (grp.loc[i, "entry_dt"] < grp.loc[i-1, "exit_dt"] and
                    grp.loc[i, "zone_id"] != grp.loc[i-1, "zone_id"]):
                violations += 1

    trajs_with_violation = violations  # upper bound
    value = round(100.0 * (1 - violations / max(len(j), 1)), 2)

    log.info("Consistencia: %.2f%%  (violacoes: %d)", value, violations)
    return {
        "value":               value,
        "violations":          violations,
        "total_trajectories":  total,
        "passed":              violations == 0,
        "note":                "Alvo: 100%. Qualquer violacao indica erro no stitcher.",
    }


# ── Metrica 2: Cobertura ──────────────────────────────────────────────────────

def calc_cobertura(journeys_df: pd.DataFrame, events_df: pd.DataFrame) -> dict:
    """
    % de eventos do dataset original atribuidos a alguma trajectória.
    Cada zone visit cobre aprox. 2-3 eventos (entry + linger? + exit).
    """
    n_events  = len(events_df)
    n_visits  = len(journeys_df)

    if n_events == 0:
        return {"value": 0.0, "events_total": 0, "visits_total": 0}

    # Estimativa: visita com linger = 3 eventos; sem linger = 2 eventos
    linger_v       = journeys_df["dwell_s"].gt(0).sum() if not journeys_df.empty else 0
    no_linger      = n_visits - linger_v
    events_covered = linger_v * 3 + no_linger * 2
    value          = round(min(100.0, 100.0 * events_covered / n_events), 2)

    log.info("Cobertura: %.2f%%  (%d eventos, ~%d cobertos)", value, n_events, events_covered)
    return {
        "value":          value,
        "events_total":   n_events,
        "visits_total":   n_visits,
        "events_covered": int(events_covered),
        "note":           "Estimativa: entry+linger+exit = 3 eventos por visit com linger, 2 sem.",
    }


# ── Metrica 3: Completude ─────────────────────────────────────────────────────

def calc_completude(journeys_df: pd.DataFrame) -> dict:
    """
    % de trajectórias com inicio em Z_E e fim em Z_E ou Z_CK.
    Trajectórias parciais (inicio/fim do dia) sao inevitaveis.
    """
    if journeys_df.empty:
        return {"value": 0.0, "complete": 0, "total": 0}

    j = journeys_df.copy()
    j["entry_dt"] = pd.to_datetime(j["entry_time"])
    j_s = j.sort_values(["person_id", "entry_dt"])

    first_z = j_s.groupby("person_id")["zone_id"].first()
    last_z  = j_s.groupby("person_id")["zone_id"].last()
    total   = j["person_id"].nunique()

    has_entry = first_z.isin(ENTRY_ZONES)
    has_exit  = last_z.isin(EXIT_ZONES)
    complete  = (has_entry & has_exit).sum()
    value     = round(100.0 * complete / max(total, 1), 2)

    log.info("Completude: %.2f%%  (%d/%d trajectórias completas)", value, complete, total)
    return {
        "value":              value,
        "complete":           int(complete),
        "total_trajectories": int(total),
        "start_in_ze_pct":   round(100.0 * has_entry.sum() / max(total,1), 2),
        "end_in_exit_pct":   round(100.0 * has_exit.sum()  / max(total,1), 2),
        "note":               "Trajectórias parciais (inicio/fim do dia) sao esperadas.",
    }


# ── Metrica 4: Detecao de anomalias ──────────────────────────────────────────

def calc_detecao_anomalias(journeys_df: pd.DataFrame, insights: dict) -> dict:
    """
    Detecta anomalias estatisticamente (2 sigma, ultimos dias vs baseline)
    e verifica se estao mencionadas nos insights do LLM.

    Logica:
      - Baseline = todos os dias excepto o ultimo
      - Anomalias = zona/hora com desvio > 2 sigma no ultimo dia
      - Verificar se zona e hora aparecem nos insights de categoria 'anomalia'
    """
    if journeys_df.empty:
        return {"value": 0.0, "detected": 0, "total_injected": 0}

    j = journeys_df.copy()
    j["entry_dt"]  = pd.to_datetime(j["entry_time"])
    j["visit_date"] = j["entry_dt"].dt.date
    j["hour"]       = j["entry_dt"].dt.hour

    dates          = sorted(j["visit_date"].unique())
    baseline_dates = dates[:-1]
    last_date      = dates[-1] if len(dates) >= 2 else None

    if last_date is None:
        return {"value": 0.0, "detected": 0, "total_injected": 0,
                "note": "Dataset com menos de 2 dias -- impossivel calcular baseline."}

    traffic = (
        j.groupby(["visit_date", "zone_id", "hour"])["person_id"]
        .nunique().reset_index().rename(columns={"person_id": "visitors"})
    )
    baseline = traffic[traffic["visit_date"].isin(baseline_dates)]
    stats    = (
        baseline.groupby(["zone_id", "hour"])["visitors"]
        .agg(mean="mean", std="std").fillna(0).reset_index()
    )
    last_day = traffic[traffic["visit_date"] == last_date].copy()
    last_day = last_day.merge(stats, on=["zone_id", "hour"], how="left")
    last_day["std"]   = last_day["std"].fillna(0)
    last_day["mean"]  = last_day["mean"].fillna(0)
    last_day["sigma"] = last_day.apply(
        lambda r: abs(r["visitors"] - r["mean"]) / r["std"]
        if r["std"] > 0 else 0.0, axis=1
    )
    anomalies = last_day[last_day["sigma"] > SIGMA_THRESHOLD]

    # Verificar se anomalias aparecem nos insights
    insight_list   = insights.get("insights", [])
    anom_insights  = [i for i in insight_list if i.get("categoria") == "anomalia"]
    insight_text   = " ".join(
        i.get("observacao","") + " " + i.get("titulo","")
        for i in anom_insights
    ).lower()

    detected = 0
    details  = []
    for _, row in anomalies.iterrows():
        zone  = str(row["zone_id"])
        hour  = str(int(row["hour"]))
        found = zone.lower() in insight_text and hour in insight_text
        details.append({
            "zone":     zone,
            "hour":     int(row["hour"]),
            "visitors": int(row["visitors"]),
            "mean":     round(float(row["mean"]), 1),
            "sigma":    round(float(row["sigma"]), 1),
            "in_insights": found,
        })
        if found:
            detected += 1

    total = len(anomalies)
    value = round(100.0 * detected / max(total, 1), 2)

    log.info("Detecao anomalias: %.2f%%  (%d/%d identificadas nos insights)",
             value, detected, total)
    return {
        "value":          value,
        "detected":       detected,
        "total_injected": total,
        "anomaly_day":    str(last_date),
        "details":        details[:10],
        "note":           "Anomalias = desvio > 2 sigma no ultimo dia vs baseline.",
    }


# ── Metrica 5: Precisao numerica ──────────────────────────────────────────────

def calc_precisao_numerica(insights: dict, metrics: dict) -> dict:
    """
    % de valores numericos nos insights que sao verificaveis nos dados calculados.
    Estrategia: extrair todos os numeros dos insights e verificar se aparecem
    no metrics.json (conversao para string e busca).
    """
    insight_list = insights.get("insights", [])
    if not insight_list:
        return {"value": 0.0, "verified": 0, "total": 0}

    # Texto plano de todas as metricas para busca
    metrics_str = json.dumps(metrics, ensure_ascii=False)

    total    = 0
    verified = 0
    details  = []

    for ins in insight_list:
        text = ins.get("observacao", "") + " " + ins.get("titulo", "")
        # Extrair numeros do insight
        numbers = re.findall(r'\b\d+[\.,]?\d*\b', text)
        for num in numbers:
            total += 1
            # Normalizar: remover zeros a seguir a virgula desnecessarios
            num_clean = num.replace(",", ".")
            try:
                val = float(num_clean)
                # Verificar se o valor aparece no metrics.json
                # Aceitar margem de +-5% para arredondamentos
                found = False
                for candidate in re.findall(r'\d+\.?\d*', metrics_str):
                    try:
                        cval = float(candidate)
                        if cval > 0 and abs(val - cval) / cval < 0.05:
                            found = True
                            break
                    except ValueError:
                        pass
                if found:
                    verified += 1
                details.append({"number": num, "verified": found,
                                 "insight_id": ins.get("id","?")})
            except ValueError:
                pass

    value = round(100.0 * verified / max(total, 1), 2)
    log.info("Precisao numerica: %.2f%%  (%d/%d numeros verificados)", value, verified, total)
    return {
        "value":    value,
        "verified": verified,
        "total":    total,
        "details":  details[:20],
        "note":     "Margem de 5% aceite para arredondamentos.",
    }


# ── Metrica 6: Ausencia de alucinacao ────────────────────────────────────────

def calc_ausencia_alucinacao(report_text: str, metrics: dict) -> dict:
    """
    % de afirmacoes factuais no report verificaveis no metrics.json.
    Estrategia: extrair numeros do report e verificar se existem nos dados.
    Mesma logica da precisao numerica mas aplicada ao report em vez dos insights.
    """
    if not report_text:
        return {"value": 0.0, "verified": 0, "total": 0,
                "note": "Report nao gerado."}

    metrics_str = json.dumps(metrics, ensure_ascii=False)
    numbers     = re.findall(r'\b\d+[\.,]?\d*\b', report_text)

    total    = 0
    verified = 0

    for num in numbers:
        # Ignorar anos, horas e numeros de secao (muito curtos ou muito especificos)
        try:
            val = float(num.replace(",", "."))
            if val < 2 or val > 1_000_000:
                continue   # ignorar 0/1 e valores implausíveis
            total += 1
            for candidate in re.findall(r'\d+\.?\d*', metrics_str):
                try:
                    cval = float(candidate)
                    if cval > 0 and abs(val - cval) / cval < 0.05:
                        verified += 1
                        break
                except ValueError:
                    pass
        except ValueError:
            pass

    value = round(100.0 * verified / max(total, 1), 2)
    log.info("Ausencia alucinacao: %.2f%%  (%d/%d valores do report verificados)",
             value, verified, total)
    return {
        "value":    value,
        "verified": verified,
        "total":    total,
        "note":     "Valores numericos do report verificados contra metrics.json (margem 5%).",
    }


# ── Montar relatorio final ────────────────────────────────────────────────────

def build_report(results: dict, data_path: str) -> dict:
    metrics_list = [
        ("consistencia",        results["consistencia"]["value"],       100.0),
        ("cobertura",           results["cobertura"]["value"],          90.0),
        ("completude",          results["completude"]["value"],         50.0),
        ("detecao_anomalias",   results["detecao_anomalias"]["value"],  50.0),
        ("precisao_numerica",   results["precisao_numerica"]["value"],  70.0),
        ("ausencia_alucinacao", results["ausencia_alucinacao"]["value"],70.0),
    ]

    scores    = [v for _, v, _ in metrics_list]
    global_score = round(sum(scores) / len(scores), 2)

    # Converter para bool Python nativo (numpy.bool_ nao e serializavel em JSON)
    passed = {
        name: bool(val >= threshold)
        for name, val, threshold in metrics_list
    }

    return {
        "dataset":      str(data_path),
        "global_score": float(global_score),
        "metrics": {
            "consistencia":        round(results["consistencia"]["value"], 2),
            "cobertura":           round(results["cobertura"]["value"], 2),
            "completude":          round(results["completude"]["value"], 2),
            "detecao_anomalias":   round(results["detecao_anomalias"]["value"], 2),
            "precisao_numerica":   round(results["precisao_numerica"]["value"], 2),
            "ausencia_alucinacao": round(results["ausencia_alucinacao"]["value"], 2),
        },
    }


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Harness de avaliacao end-to-end do pipeline de retalho."
    )
    ap.add_argument("--data",   required=True,
                    help="Dataset de validacao (events_validation.csv)")
    ap.add_argument("--output", required=True,
                    help="Ficheiro de saida (evaluation_report.json)")
    args = ap.parse_args()

    data_path   = args.data
    output_path = args.output

    if not Path(data_path).exists():
        log.error("Dataset nao encontrado: %s", data_path)
        sys.exit(1)

    log.info("══ Harness de Avaliacao ══════════════════════════════════")
    log.info("Dataset : %s", data_path)
    log.info("Output  : %s", output_path)
    log.info("═════════════════════════════════════════════════════════")

    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)

        # Correr pipeline completo
        pipeline = run_pipeline(data_path, tmp_dir)

        # Calcular metricas
        log.info("── Calculando metricas ─────────────────────────────────")
        results = {
            "consistencia":        calc_consistencia(pipeline["journeys_df"]),
            "cobertura":           calc_cobertura(pipeline["journeys_df"], pipeline["events_df"]),
            "completude":          calc_completude(pipeline["journeys_df"]),
            "detecao_anomalias":   calc_detecao_anomalias(pipeline["journeys_df"], pipeline["insights"]),
            "precisao_numerica":   calc_precisao_numerica(pipeline["insights"], pipeline["metrics"]),
            "ausencia_alucinacao": calc_ausencia_alucinacao(pipeline["report_text"], pipeline["metrics"]),
        }

    # Montar e guardar relatorio
    report = build_report(results, data_path)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    # Resumo no terminal
    log.info("══ Resultados ════════════════════════════════════════════")
    for name, val in report["metrics"].items():
        log.info("  %-25s : %.2f%%", name, val)
    log.info("  Score global: %.2f%%", report["global_score"])
    log.info("═════════════════════════════════════════════════════════")
    log.info("evaluation_report.json -> %s", output_path)


if __name__ == "__main__":
    main()