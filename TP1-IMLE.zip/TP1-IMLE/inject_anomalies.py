#!/usr/bin/env python3
"""
inject_anomalies.py -- Injector de Anomalias para Teste do Harness

Cria um dataset de validacao proprio injetando anomalias conhecidas no
events.csv original. Permite testar o harness antes de receber o
dataset de validacao do professor.

Uso:
    python inject_anomalies.py
    python inject_anomalies.py --input data/events.csv --output data/events_validation.csv

Anomalias injetadas (documentadas para o relatorio):
  A1. Pico de trafego anormal    -- duplicar eventos numa zona/hora especifica
  A2. Zona fantasma              -- remover todos os eventos de uma zona numa hora
  A3. Atributos inconsistentes   -- alterar gender mid-trajectory para a mesma pessoa
  A4. Spike de linger            -- aumentar drasticamente dwell_s numa zona
  A5. Inversao de fluxo          -- injetar entradas em Z_CK (zona de saida)

Seed fixo (42) para reproducibilidade.
"""

import argparse
import logging
import random
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("inject_anomalies")

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "data" / "events.csv").exists():
            return path
    return Path.cwd()


ROOT           = _find_root()
DEFAULT_INPUT  = ROOT / "data" / "events.csv"
DEFAULT_OUTPUT = ROOT / "data" / "events_validation.csv"


# ── Carregar dados ─────────────────────────────────────────────────────────────

def load_events(path):
    df = pd.read_csv(path, dtype=str)
    df.columns = [c.strip().lower() for c in df.columns]
    df["timestamp"] = pd.to_datetime(df["timestamp"], dayfirst=True, format="mixed")
    df["duration_s"] = pd.to_numeric(df["duration_s"], errors="coerce").fillna(0).astype(int)
    df = df.sort_values(["timestamp", "event_id"]).reset_index(drop=True)
    log.info("Carregados %d eventos de '%s'", len(df), path)
    return df


# ── Anomalia A1: Pico de tráfego anormal ──────────────────────────────────────

def inject_traffic_spike(df: pd.DataFrame, zone: str = "Z_S3",
                          target_date: str = "2025-03-16",
                          target_hour: int = 14,
                          multiplier: int = 3) -> tuple[pd.DataFrame, dict]:
    """
    Duplica os eventos de entry/exit de uma zona numa hora especifica,
    criando um pico de trafego anormalmente alto.
    Simula: promocao nao planeada, evento especial, erro de sensor.
    """
    mask = (
        (df["timestamp"].dt.date.astype(str) == target_date) &
        (df["timestamp"].dt.hour == target_hour) &
        (df["zone_id"] == zone)
    )
    target_events = df[mask].copy()

    if target_events.empty:
        log.warning("A1: Nenhum evento encontrado para %s %s %dh", zone, target_date, target_hour)
        return df, {}

    new_rows = []
    base_id  = df["event_id"].str.extract(r'(\d+)').astype(float).max().values[0]

    for _ in range(multiplier - 1):
        dupes = target_events.copy()
        dupes["event_id"] = [
            "e_{:06.0f}".format(base_id + i + 1)
            for i in range(len(dupes))
        ]
        # Adicionar offset de segundos para nao colidir
        dupes["timestamp"] = dupes["timestamp"] + pd.Timedelta(seconds=30 * (_ + 1))
        new_rows.append(dupes)
        base_id += len(dupes)

    df_new = pd.concat([df] + new_rows, ignore_index=True)
    df_new = df_new.sort_values(["timestamp", "event_id"]).reset_index(drop=True)

    n_added = sum(len(r) for r in new_rows)
    log.info("A1 (pico trafego): +%d eventos em %s %s %dh (x%d)",
             n_added, zone, target_date, target_hour, multiplier)

    return df_new, {
        "tipo":        "A1_pico_trafego",
        "zona":        zone,
        "data":        target_date,
        "hora":        target_hour,
        "eventos_add": n_added,
        "descricao":   f"Trafego em {zone} as {target_hour}h de {target_date} multiplicado por {multiplier}x",
    }


# ── Anomalia A2: Zona fantasma (trafego zero) ──────────────────────────────────

def inject_ghost_zone(df: pd.DataFrame, zone: str = "Z_N4",
                       target_date: str = "2025-03-16",
                       target_hour: int = 16) -> tuple[pd.DataFrame, dict]:
    """
    Remove todos os eventos de uma zona numa hora especifica.
    Simula: corredor bloqueado, zona encerrada, falha de sensor.
    """
    mask = (
        (df["timestamp"].dt.date.astype(str) == target_date) &
        (df["timestamp"].dt.hour == target_hour) &
        (df["zone_id"] == zone)
    )
    n_removed = mask.sum()

    if n_removed == 0:
        log.warning("A2: Nenhum evento para remover em %s %s %dh", zone, target_date, target_hour)
        return df, {}

    df_new = df[~mask].reset_index(drop=True)
    log.info("A2 (zona fantasma): -%d eventos em %s %s %dh",
             n_removed, zone, target_date, target_hour)

    return df_new, {
        "tipo":          "A2_zona_fantasma",
        "zona":          zone,
        "data":          target_date,
        "hora":          target_hour,
        "eventos_remove": int(n_removed),
        "descricao":     f"Todos os eventos de {zone} as {target_hour}h de {target_date} removidos (0 visitantes)",
    }


# ── Anomalia A3: Spike de dwell time ──────────────────────────────────────────

def inject_dwell_spike(df: pd.DataFrame, zone: str = "Z_S1",
                        target_date: str = "2025-03-16",
                        multiplier: float = 5.0) -> tuple[pd.DataFrame, dict]:
    """
    Aumenta drasticamente o dwell_s dos eventos linger numa zona.
    Simula: fila de espera anormal, problema operacional, evento especial.
    """
    mask = (
        (df["timestamp"].dt.date.astype(str) == target_date) &
        (df["zone_id"] == zone) &
        (df["event_type"] == "linger") &
        (df["duration_s"] > 0)
    )
    n_affected = mask.sum()

    if n_affected == 0:
        log.warning("A3: Nenhum linger em %s %s", zone, target_date)
        return df, {}

    df_new = df.copy()
    original_mean = df_new.loc[mask, "duration_s"].mean()
    df_new.loc[mask, "duration_s"] = (df_new.loc[mask, "duration_s"] * multiplier).astype(int)
    new_mean = df_new.loc[mask, "duration_s"].mean()

    log.info("A3 (dwell spike): %d lingers em %s %s: media %.0fs -> %.0fs (x%.1f)",
             n_affected, zone, target_date, original_mean, new_mean, multiplier)

    return df_new, {
        "tipo":         "A3_dwell_spike",
        "zona":         zone,
        "data":         target_date,
        "multiplier":   multiplier,
        "eventos_afect": int(n_affected),
        "dwell_antes":  round(float(original_mean), 1),
        "dwell_depois": round(float(new_mean), 1),
        "descricao":    f"Dwell time em {zone} de {target_date} aumentado {multiplier}x (media {original_mean:.0f}s -> {new_mean:.0f}s)",
    }


# ── Anomalia A4: Pico no final do dia ─────────────────────────────────────────

def inject_late_spike(df: pd.DataFrame, zone: str = "Z_C2",
                       target_date: str = "2025-03-16",
                       target_hour: int = 21) -> tuple[pd.DataFrame, dict]:
    """
    Injeta eventos anormais no final do dia (hora de fecho).
    Simula: fila de espera no fecho, registo tardio de eventos.
    """
    # Usar eventos de uma hora de pico como template
    template_mask = (
        (df["timestamp"].dt.date.astype(str) == target_date) &
        (df["timestamp"].dt.hour == 11) &
        (df["zone_id"] == zone)
    )
    template = df[template_mask].copy()

    if template.empty:
        log.warning("A4: Template vazio para %s", zone)
        return df, {}

    # Mover para a hora de fecho
    base_id = df["event_id"].str.extract(r'(\d+)').astype(float).max().values[0]
    new_ts  = template["timestamp"].apply(
        lambda t: t.replace(hour=target_hour, minute=0, second=0)
    )
    template = template.copy()
    template["timestamp"] = new_ts
    template["event_id"]  = [
        "e_{:06.0f}".format(base_id + i + 1)
        for i in range(len(template))
    ]

    df_new = pd.concat([df, template], ignore_index=True)
    df_new = df_new.sort_values(["timestamp", "event_id"]).reset_index(drop=True)

    log.info("A4 (pico tardio): +%d eventos em %s %s %dh",
             len(template), zone, target_date, target_hour)

    return df_new, {
        "tipo":        "A4_pico_tardio",
        "zona":        zone,
        "data":        target_date,
        "hora":        target_hour,
        "eventos_add": len(template),
        "descricao":   f"Pico anormal de {len(template)} eventos em {zone} as {target_hour}h de {target_date}",
    }


# ── Anomalia A5: Eventos em zona de saida ─────────────────────────────────────

def inject_exit_zone_events(df: pd.DataFrame,
                              target_date: str = "2025-03-16",
                              n_events: int = 50) -> tuple[pd.DataFrame, dict]:
    """
    Injeta eventos de entry em Z_CK (zona de saida definitiva).
    Simula: falha de sensor, pessoas a reentrar apos checkout.
    Z_CK so devia ter exits -- entries sao fisicamente anomalas.
    """
    # Template: pegar eventos de Z_C1 do mesmo dia
    template_mask = (
        (df["timestamp"].dt.date.astype(str) == target_date) &
        (df["zone_id"] == "Z_C1") &
        (df["event_type"] == "entry")
    )
    template = df[template_mask].head(n_events).copy()

    if template.empty:
        log.warning("A5: Template vazio para Z_CK")
        return df, {}

    base_id = df["event_id"].str.extract(r'(\d+)').astype(float).max().values[0]
    template["zone_id"]   = "Z_CK"
    template["event_id"]  = [
        "e_{:06.0f}".format(base_id + i + 1)
        for i in range(len(template))
    ]
    template["timestamp"] = template["timestamp"] + pd.Timedelta(minutes=5)

    df_new = pd.concat([df, template], ignore_index=True)
    df_new = df_new.sort_values(["timestamp", "event_id"]).reset_index(drop=True)

    log.info("A5 (entries Z_CK): +%d eventos entry em Z_CK em %s", len(template), target_date)

    return df_new, {
        "tipo":        "A5_entries_zck",
        "zona":        "Z_CK",
        "data":        target_date,
        "eventos_add": len(template),
        "descricao":   f"{len(template)} eventos entry injetados em Z_CK (zona de saida) em {target_date}",
    }


# ── Pipeline principal ─────────────────────────────────────────────────────────

def run(input_path: str, output_path: str) -> dict:
    """
    Injeta todas as anomalias e guarda o dataset de validacao.
    Devolve dicionario com as anomalias injetadas (para documentacao).
    """
    df = load_events(input_path)
    n_original = len(df)

    # Usar o ultimo dia do dataset como dia de anomalias
    last_date = str(df["timestamp"].dt.date.max())
    log.info("Dia de anomalias: %s", last_date)

    anomalias = []

    # A1: Pico de trafego em Z_S3 as 14h
    df, a1 = inject_traffic_spike(df, zone="Z_S3", target_date=last_date,
                                   target_hour=14, multiplier=3)
    if a1:
        anomalias.append(a1)

    # A2: Zona fantasma em Z_N4 as 16h
    df, a2 = inject_ghost_zone(df, zone="Z_N4", target_date=last_date, target_hour=16)
    if a2:
        anomalias.append(a2)

    # A3: Dwell spike em Z_S1
    df, a3 = inject_dwell_spike(df, zone="Z_S1", target_date=last_date, multiplier=5.0)
    if a3:
        anomalias.append(a3)

    # A4: Pico tardio em Z_C2 as 21h
    df, a4 = inject_late_spike(df, zone="Z_C2", target_date=last_date, target_hour=21)
    if a4:
        anomalias.append(a4)

    # A5: Entries em Z_CK
    df, a5 = inject_exit_zone_events(df, target_date=last_date, n_events=30)
    if a5:
        anomalias.append(a5)

    # Guardar dataset
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    # Formatar timestamp de volta ao formato original
    df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
    df.to_csv(out, index=False)

    n_final = len(df)
    log.info("Dataset de validacao guardado: %s (%d eventos, +%d anomalos)",
             out, n_final, n_final - n_original)

    # Guardar manifesto das anomalias (para verificar no harness)
    manifesto_path = out.parent / "anomalies_manifest.json"
    import json
    manifesto = {
        "source":          str(input_path),
        "output":          str(output_path),
        "seed":            RANDOM_SEED,
        "anomaly_day":     last_date,
        "n_anomalies":     len(anomalias),
        "anomalies":       anomalias,
    }
    with open(manifesto_path, "w", encoding="utf-8") as f:
        json.dump(manifesto, f, ensure_ascii=False, indent=2)
    log.info("Manifesto de anomalias: %s", manifesto_path)

    # Resumo
    log.info("══ Anomalias injetadas ═══════════════════════════════════")
    for a in anomalias:
        log.info("  %s: %s", a["tipo"], a["descricao"])
    log.info("═════════════════════════════════════════════════════════")

    return manifesto


# ── Execucao directa ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Injeta anomalias conhecidas no events.csv para teste do harness"
    )
    ap.add_argument("--input",  default=str(DEFAULT_INPUT))
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    args = ap.parse_args()
    run(args.input, args.output)