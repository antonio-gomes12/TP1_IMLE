#!/usr/bin/env python3
"""
analytics.py -- Fase 2: Pipeline Analítico

Le output/journeys.csv e produz output/metrics.json com metricas
pre-calculadas em Python puro. A LLM recebe este JSON como unico input.

Output compacto: optimizado para caber no contexto do mistral:7b (~8K tokens).
Inclui apenas os valores mais relevantes para gerar insights accionaveis.

Uso:
    python src/analytics.py --input output/journeys.csv --output output/metrics.json

Importavel:
    from analytics import run as run_analytics

Complexidade: O(n log n) dominada pelos groupby do pandas.
"""

import argparse
import json
import logging
from collections import Counter
from pathlib import Path

import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("analytics")

# ── Paths ─────────────────────────────────────────────────────────────────────

def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent.parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "output" / "journeys.csv").exists():
            return path
    return Path.cwd()


ROOT           = _find_root()
DEFAULT_INPUT  = ROOT / "output" / "journeys.csv"
DEFAULT_OUTPUT = ROOT / "output" / "metrics.json"

ENTRY_ZONES    = {"Z_E1", "Z_E2"}
CHECKOUT_ZONES = {"Z_C1", "Z_C2", "Z_C3"}
EXIT_ZONE      = "Z_CK"


# ── Carregar dados ────────────────────────────────────────────────────────────

def load_journeys(path):
    df = pd.read_csv(path)
    df["entry_time"]  = pd.to_datetime(df["entry_time"])
    df["exit_time"]   = pd.to_datetime(df["exit_time"])
    df["visit_date"]  = pd.to_datetime(df["visit_date"]).dt.date
    df["hour_of_day"] = df["hour_of_day"].astype(int)
    df["dwell_s"]     = pd.to_numeric(df["dwell_s"], errors="coerce").fillna(0)
    log.info("Carregado: %d linhas, %d pessoas, %d zonas",
             len(df), df["person_id"].nunique(), df["zone_id"].nunique())
    return df


# ── 1. Tráfego ────────────────────────────────────────────────────────────────

def calc_traffic(df):
    log.info("Calculando trafego...")

    dates = sorted(df["visit_date"].unique())
    n_days = len(dates)
    n_visitors = df["person_id"].nunique()

    by_day = df.groupby("visit_date")["person_id"].nunique()

    by_hour = (
        df.groupby(["visit_date", "hour_of_day"])["person_id"].nunique()
        .reset_index()
        .groupby("hour_of_day")["person_id"].mean()
        .round(1)
    )
    peak_hour = int(by_hour.idxmax())

    df2 = df.copy()
    df2["weekday"] = df2["entry_time"].dt.day_name()
    weekday_avg = (
        df2.groupby(["visit_date", "weekday"])["person_id"].nunique()
        .reset_index()
        .groupby("weekday")["person_id"].mean()
    )

    durations = df.groupby(["person_id", "visit_date"]).apply(
        lambda g: (g["exit_time"].max() - g["entry_time"].min()).total_seconds() / 60,
        include_groups=False,
    )

    return {
        "total_visitors":          int(n_visitors),
        "total_days":              int(n_days),
        "avg_visitors_per_day":    round(float(by_day.mean()), 1),
        "max_visitors_day":        {"date": str(by_day.idxmax()), "count": int(by_day.max())},
        "min_visitors_day":        {"date": str(by_day.idxmin()), "count": int(by_day.min())},
        "peak_hour":               peak_hour,
        "peak_hour_avg_visitors":  round(float(by_hour.max()), 1),
        "best_weekday":            str(weekday_avg.idxmax()),
        "worst_weekday":           str(weekday_avg.idxmin()),
        "avg_visit_duration_min":  round(float(durations.mean()), 1),
        "p95_visit_duration_min":  round(float(durations.quantile(0.95)), 1),
        "visitors_per_day":        {str(k): int(v) for k, v in by_day.items()},
        "avg_visitors_per_hour":   {int(h): round(float(v), 1) for h, v in by_hour.items()},
    }


# ── 2. Zonas ──────────────────────────────────────────────────────────────────

def calc_zones(df):
    log.info("Calculando zonas...")

    zone_traffic = (
        df.groupby("zone_id")["person_id"].nunique()
        .sort_values(ascending=False)
    )

    linger_df = df[df["dwell_s"] > 0]
    zone_dwell = linger_df.groupby("zone_id")["dwell_s"].mean().round(1)

    total_z  = df.groupby("zone_id")["person_id"].nunique()
    linger_z = linger_df.groupby("zone_id")["person_id"].nunique()
    stop_rate = (linger_z / total_z).fillna(0).round(3)

    seqs = []
    for _, grp in df.groupby("person_id"):
        zones = grp.sort_values("entry_time")["zone_id"].tolist()
        for a, b in zip(zones, zones[1:]):
            if a != b:
                seqs.append(f"{a} -> {b}")
    top10 = [{"seq": s, "n": c} for s, c in Counter(seqs).most_common(10)]

    top_zone       = str(zone_traffic.idxmax())
    top_dwell_zone = str(zone_dwell.idxmax()) if not zone_dwell.empty else "?"
    top_stop_zone  = str(stop_rate.idxmax())  if not stop_rate.empty  else "?"

    return {
        "top_zone":          top_zone,
        "top_zone_visitors": int(zone_traffic.max()),
        "top_dwell_zone":    top_dwell_zone,
        "top_dwell_avg_s":   float(zone_dwell.max()) if not zone_dwell.empty else 0,
        "top_stop_zone":     top_stop_zone,
        "top_stop_rate":     round(float(stop_rate.max()) * 100, 1) if not stop_rate.empty else 0,
        "zone_traffic":      {str(k): int(v) for k, v in zone_traffic.items()},
        "zone_dwell_avg_s":  {str(k): float(v) for k, v in zone_dwell.items()},
        "zone_stop_rate_pct":{str(k): round(float(v)*100, 1) for k, v in stop_rate.items()},
        "top_10_sequences":  top10,
    }


# ── 3. Funil ──────────────────────────────────────────────────────────────────

def calc_funnel(df):
    log.info("Calculando funil...")

    all_pids = set(df["person_id"].unique())
    n_total  = len(all_pids)

    reached_checkout = set(df[df["zone_id"].isin(CHECKOUT_ZONES)]["person_id"])
    reached_zck      = set(df[df["zone_id"] == EXIT_ZONE]["person_id"])
    no_checkout      = all_pids - reached_checkout

    df_no = df[df["person_id"].isin(no_checkout)].drop_duplicates("person_id")

    # Alcance por zona (% de visitantes que passaram por cada zona)
    zone_reach = {}
    for zone in sorted(df["zone_id"].unique()):
        pids = set(df[df["zone_id"] == zone]["person_id"])
        zone_reach[zone] = round(100.0 * len(pids) / max(n_total, 1), 1)

    return {
        "total_visitors":         n_total,
        "reached_checkout_count": len(reached_checkout),
        "reached_checkout_pct":   round(100.0 * len(reached_checkout) / max(n_total, 1), 1),
        "converted_zck_count":    len(reached_zck),
        "converted_zck_pct":      round(100.0 * len(reached_zck) / max(n_total, 1), 1),
        "no_checkout_count":      len(no_checkout),
        "no_checkout_pct":        round(100.0 * len(no_checkout) / max(n_total, 1), 1),
        "zone_reach_pct":         zone_reach,
        "no_checkout_profile": {
            "gender_dist": df_no["gender"].value_counts(normalize=True).round(3).to_dict(),
            "age_dist":    df_no["age_range"].value_counts(normalize=True).round(3).to_dict(),
            "avg_zones":   round(float(
                df[df["person_id"].isin(no_checkout)]
                .groupby("person_id")["zone_id"].nunique().mean()
            ), 1) if no_checkout else 0.0,
        },
    }


# ── 4. Demografico ────────────────────────────────────────────────────────────

def calc_demographics(df):
    log.info("Calculando demograficos...")

    linger_df = df[df["dwell_s"] > 0]

    gender_overall = df.drop_duplicates("person_id")["gender"].value_counts(normalize=True).round(3).to_dict()
    age_overall    = df.drop_duplicates("person_id")["age_range"].value_counts(normalize=True).round(3).to_dict()

    # Dwell por segmento (top 5 para nao inflar o JSON)
    dwell_seg = (
        linger_df.groupby(["gender", "age_range"])["dwell_s"].mean()
        .round(1).reset_index()
        .rename(columns={"dwell_s": "avg_dwell_s"})
        .sort_values("avg_dwell_s", ascending=False)
        .head(5)
        .to_dict(orient="records")
    )

    # Hora de pico por genero
    gender_hour = (
        df.drop_duplicates(["person_id", "visit_date", "hour_of_day"])
        .groupby(["hour_of_day", "gender"])["person_id"].count()
        .unstack(fill_value=0)
        .apply(lambda r: (r / r.sum()).round(3), axis=1)
        .to_dict(orient="index")
    )

    return {
        "gender_overall":    gender_overall,
        "age_overall":       age_overall,
        "top_dwell_segments": dwell_seg,
        "gender_by_hour":    {int(k): v for k, v in gender_hour.items()},
    }


# ── 5. Anomalias ──────────────────────────────────────────────────────────────

def calc_anomalies(df):
    log.info("Calculando anomalias...")

    dates          = sorted(df["visit_date"].unique())
    baseline_dates = dates[:6]
    day7_date      = dates[6] if len(dates) >= 7 else None

    traffic = (
        df.groupby(["visit_date", "zone_id", "hour_of_day"])["person_id"]
        .nunique().reset_index().rename(columns={"person_id": "visitors"})
    )

    baseline = traffic[traffic["visit_date"].isin(baseline_dates)]
    stats = (
        baseline.groupby(["zone_id", "hour_of_day"])["visitors"]
        .agg(mean="mean", std="std").fillna(0).reset_index()
    )

    anomalies = []
    if day7_date is not None:
        day7 = traffic[traffic["visit_date"] == day7_date].copy()
        day7 = day7.merge(stats, on=["zone_id", "hour_of_day"], how="left")
        day7["std"]   = day7["std"].fillna(0)
        day7["mean"]  = day7["mean"].fillna(0)
        day7["sigma"] = day7.apply(
            lambda r: abs(r["visitors"] - r["mean"]) / r["std"]
            if r["std"] > 0 else 0.0, axis=1,
        )
        anom_df   = day7[day7["sigma"] > 2].sort_values("sigma", ascending=False)
        anomalies = (
            anom_df[["zone_id","hour_of_day","visitors","mean","std","sigma"]]
            .round(2).head(10)   # top 10 anomalias
            .to_dict(orient="records")
        )

    return {
        "baseline_days":   [str(d) for d in baseline_dates],
        "anomaly_day":     str(day7_date) if day7_date else None,
        "total_anomalies": len(anomalies),
        "anomalies":       anomalies,
    }


# ── Pipeline principal ────────────────────────────────────────────────────────

def build_metrics(df):
    return {
        "generated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source":       "journeys.csv",
        "traffic":      calc_traffic(df),
        "zones":        calc_zones(df),
        "funnel":       calc_funnel(df),
        "demographics": calc_demographics(df),
        "anomalies":    calc_anomalies(df),
    }


# ── API ───────────────────────────────────────────────────────────────────────

def run(input_path, output_path):
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    df      = load_journeys(input_path)
    metrics = build_metrics(df)

    with open(out, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2, default=str)

    size_kb = out.stat().st_size / 1024
    log.info("metrics.json -> %s  (%.1f KB)", out, size_kb)
    log.info("  Anomalias: %d  |  Zonas: %d",
             metrics["anomalies"]["total_anomalies"],
             len(metrics["zones"]["zone_traffic"]))
    return metrics


# ── Execucao directa ──────────────────────────────────────────────────────────
# python src/analytics.py --input output/journeys.csv --output output/metrics.json

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Analytics: calcula metricas a partir de journeys.csv"
    )
    ap.add_argument("--input",  default=str(DEFAULT_INPUT))
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    args = ap.parse_args()
    run(args.input, args.output)