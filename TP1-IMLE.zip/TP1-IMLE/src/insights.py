#!/usr/bin/env python3
"""
insights.py -- Fase 3: LLM Insight Engine

Le output/metrics.json e gera output/insights.json com insights accionaveis
em portugues usando LLM local via Ollama.

Modelo: mistral:7b (local, sem API key, sem internet)
  Escolha: recomendado pelo professor, bom em JSON estruturado,
           rapido num laptop moderno, corre completamente offline.

Pre-requisito: Ollama instalado e a correr (https://ollama.com/download)
  ollama pull mistral:7b   (so uma vez)

Uso:
    python src/insights.py --input output/metrics.json --output output/insights.json
    python src/insights.py --strategy A     # zero-shot
    python src/insights.py --strategy B     # few-shot (default)
    python src/insights.py --compare        # ambas + comparacao

Importavel:
    from insights import run as run_insights

Temperatura: 0 (reproducibilidade obrigatoria -- enunciado)
"""

import argparse
import json
import logging
import re
import time
from pathlib import Path
import requests

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("insights")

# ── Configuracao ──────────────────────────────────────────────────────────────
MODEL       = "mistral:7b"
OLLAMA_URL  = "http://localhost:11434"
TEMPERATURE = 0     # reproducibilidade obrigatoria (enunciado)
MAX_TOKENS  = 2000  # tokens de output
NUM_CTX     = 8192  # janela de contexto (8K)
SEED        = 42
TIMEOUT_S   = 300


# ── Paths ─────────────────────────────────────────────────────────────────────

def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent.parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "output" / "metrics.json").exists():
            return path
    return Path.cwd()


ROOT           = _find_root()
DEFAULT_INPUT  = ROOT / "output"  / "metrics.json"
DEFAULT_OUTPUT = ROOT / "output"  / "insights.json"
PROMPT_A       = ROOT / "prompts" / "strategy_a_zero_shot.txt"
PROMPT_B       = ROOT / "prompts" / "strategy_b_few_shot.txt"

# ── Prompts embutidos (fallback se os ficheiros .txt nao existirem) ───────────
# Parte comum a ambas as estrategias
_PROMPT_BASE = """
REGRAS OBRIGATORIAS:
- Cada insight deve conter numeros concretos dos dados (nunca ser vago).
- A observacao deve citar valores exactos (contagens, percentagens, tempos).
- A recomendacao deve ser uma accao concreta que o gestor pode executar.
- Responde APENAS com JSON valido, sem texto adicional, sem blocos de codigo.

SCHEMA OBRIGATORIO:
{
  "insights": [
    {
      "id": "INS_001",
      "categoria": "trafego|zona|funil|anomalia|demografico",
      "titulo": "frase curta (max 10 palavras)",
      "observacao": "factos e numeros concretos dos dados",
      "implicacao": "significado operacional para a loja",
      "recomendacao": "accao concreta que o gestor pode tomar",
      "urgencia": "imediata|esta_semana|proximo_mes",
      "confianca": 0.0
    }
  ],
  "resumo_executivo": "3 bullets separados por | com os insights mais importantes"
}

DADOS:
{METRICS}
"""

_PROMPT_A_DEFAULT = (
    "Es um analista de retalho experiente. Recebes metricas de uma loja "
    "calculadas em Python e deves gerar insights accionaveis em portugues europeu.\n"
    + _PROMPT_BASE
)

_PROMPT_B_DEFAULT = (
    "Es um analista de retalho experiente. Recebes metricas de uma loja "
    "calculadas em Python e deves gerar insights accionaveis em portugues europeu.\n\n"
    "EXEMPLOS DE MAU INSIGHT (NAO fazer assim):\n"
    "MAU: \"A zona de frescos teve bastante trafego.\" (sem numeros, vago)\n"
    "MAU: \"Recomenda-se melhorar o atendimento ao cliente.\" (nao accionavel)\n"
    "MAU: \"Houve uma anomalia na loja.\" (sem zona, hora, magnitude)\n\n"
    "EXEMPLOS DE BOM INSIGHT (fazer assim):\n"
    "BOM: \"A zona Z_S3 teve 847 visitantes na quinta-feira, 31% acima da media semanal.\"\n"
    "BOM: \"As quartas 12h-13h, dwell em Z_C2 foi 4.2 min -- terceira caixa reduziria para <2 min.\"\n"
    "BOM: \"No domingo as 16h, Z_N4 teve 0 visitantes vs media de 23 -- possivel obstucao.\"\n"
    + _PROMPT_BASE
)


# ── Verificar Ollama ──────────────────────────────────────────────────────────

def check_ollama():
    """Verifica se o Ollama esta acessivel e o modelo instalado."""
    try:
        resp = requests.get(OLLAMA_URL, timeout=3)
        if resp.status_code != 200:
            raise RuntimeError()
    except Exception:
        raise RuntimeError(
            "Ollama nao esta acessivel em localhost:11434.\n"
            "Abre a app Ollama e tenta de novo."
        )

    # Verificar modelo instalado
    try:
        resp  = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        models = [m["name"] for m in resp.json().get("models", [])]
        if not any(MODEL.split(":")[0] in m for m in models):
            raise RuntimeError(
                f"Modelo '{MODEL}' nao instalado.\n"
                f"Instala com:  ollama pull {MODEL}"
            )
    except RuntimeError:
        raise
    except Exception:
        pass  # se nao conseguir verificar, tenta na mesma

    log.info("Ollama pronto. Modelo: %s", MODEL)


# ── Chamada ao LLM ────────────────────────────────────────────────────────────

def call_llm(prompt: str, strategy: str) -> tuple[str, float]:
    """Envia prompt ao Ollama e devolve (resposta, segundos)."""
    payload = {
        "model":  MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": TEMPERATURE,
            "num_predict": MAX_TOKENS,
            "num_ctx":     NUM_CTX,
            "seed":        SEED,
        },
    }

    log.info("LLM [Estrategia %s] prompt=%d chars...", strategy, len(prompt))
    t0 = time.time()

    try:
        resp = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json=payload,
            timeout=TIMEOUT_S,
        )
        resp.raise_for_status()
    except requests.exceptions.Timeout:
        raise RuntimeError(
            f"Timeout ({TIMEOUT_S}s). Tenta de novo."
        )

    elapsed  = round(time.time() - t0, 1)
    resp_json = resp.json()
    raw       = resp_json.get("response", "")
    if not raw:
        # Mostrar resposta completa para debug
        log.error("Resposta vazia. JSON completo: %s", str(resp_json)[:500])
    log.info("Resposta em %.1fs (%d chars)", elapsed, len(raw))
    return raw, elapsed


# ── Parse e validacao ─────────────────────────────────────────────────────────

def parse_response(raw: str, strategy: str) -> dict:
    """Extrai JSON da resposta, robusto a markdown extra."""
    clean = re.sub(r"```(?:json)?", "", raw).replace("```", "").strip()
    try:
        return json.loads(clean)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", clean, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    raise ValueError(f"[{strategy}] Resposta nao e JSON valido:\n{raw[:400]}")


REQUIRED   = {"id","categoria","titulo","observacao",
               "implicacao","recomendacao","urgencia","confianca"}
CATEGORIAS = {"trafego","zona","funil","anomalia","demografico"}
URGENCIAS  = {"imediata","esta_semana","proximo_mes"}


def validate(data: dict, strategy: str) -> dict:
    """Valida o schema e corrige valores invalidos."""
    if "insights" not in data:
        raise ValueError(f"[{strategy}] JSON sem chave 'insights'.")
    data.setdefault("resumo_executivo", "")

    for i, ins in enumerate(data["insights"]):
        ins["id"] = "INS_{:03d}".format(i + 1)
        for f in REQUIRED:
            ins.setdefault(f, "" if f != "confianca" else 0.0)
        cat = str(ins.get("categoria","")).lower().split("|")[0]
        ins["categoria"] = cat if cat in CATEGORIAS else "trafego"
        urg = str(ins.get("urgencia","")).lower()
        ins["urgencia"] = urg if urg in URGENCIAS else "proximo_mes"
        try:
            ins["confianca"] = max(0.0, min(1.0, float(ins["confianca"])))
        except (TypeError, ValueError):
            ins["confianca"] = 0.5

    return data


# ── Avaliacao quantitativa ────────────────────────────────────────────────────

def evaluate(result: dict, strategy: str, elapsed: float) -> dict:
    """
    Metricas de qualidade baseadas na tabela do enunciado (bom vs mau insight):
      especificidade -- % de insights com numero concreto na observacao
      mencao_zona    -- % que mencionam uma zona especifica (Z_XX)
      completude     -- % de campos obrigatorios preenchidos
      score          -- 0.4*espec + 0.3*zona + 0.3*completude
    """
    insights = result.get("insights", [])
    n = max(len(insights), 1)

    espec = sum(
        1 for i in insights
        if re.search(r"\d+[\.,]?\d*", str(i.get("observacao","")))
    ) / n

    zona = sum(
        1 for i in insights
        if re.search(r"Z_[A-Z]+\d*",
                     str(i.get("observacao","")) + str(i.get("titulo","")))
    ) / n

    tf = ff = 0
    for ins in insights:
        for f in REQUIRED:
            tf += 1
            if str(ins.get(f,"")).strip() not in ("","0","0.0"):
                ff += 1
    comp  = ff / max(tf, 1)
    score = round(espec*0.4 + zona*0.3 + comp*0.3, 3)

    log.info("── Avaliacao [Estrategia %s] ──────────────────────────", strategy)
    log.info("  Insights       : %d", len(insights))
    log.info("  Especificidade : %.1f%%  (observacoes com numeros)", espec*100)
    log.info("  Mencao zona    : %.1f%%  (Z_XX presentes)", zona*100)
    log.info("  Completude     : %.1f%%  (campos preenchidos)", comp*100)
    log.info("  Score          : %.3f", score)
    log.info("  Tempo          : %.1fs", elapsed)

    return {
        "strategy": strategy, "n_insights": len(insights),
        "especificidade": round(espec,3), "mencao_zona": round(zona,3),
        "completude": round(comp,3), "score": score, "tempo_s": elapsed,
    }


# ── Resumo compacto das metricas (evita exceder contexto do modelo) ───────────

def _compact_metrics(m: dict) -> dict:
    """
    Extrai apenas os valores mais relevantes do metrics.json.
    O mistral:7b tem contexto limitado -- enviar o JSON completo
    resulta em resposta vazia. Esta funcao reduz o tamanho em ~80%.
    """
    t  = m.get("traffic", {})
    z  = m.get("zones", {})
    f  = m.get("funnel", {})
    d  = m.get("demographics", {})
    an = m.get("anomalies", {})

    # Zona com mais trafego
    zt = z.get("zone_traffic", {})
    top_zone = max(zt, key=zt.get) if zt else "?"
    top_zone_n = zt.get(top_zone, 0)

    # Zona com maior dwell
    zd = z.get("zone_dwell", {})
    top_dwell_zone = max(zd, key=lambda k: zd[k].get("avg_dwell_s", 0)) if zd else "?"
    top_dwell_s = zd.get(top_dwell_zone, {}).get("avg_dwell_s", 0) if zd else 0

    # Top 5 sequencias
    top_seqs = z.get("top_10_sequences", [])[:5]

    # Top 3 anomalias
    top_anom = an.get("anomalies", [])[:3]

    return {
        "INSTRUCAO": "Gera 1 insight por cada uma das 5 seccoes abaixo. Nao omitas nenhuma.",
        "SECCAO_1_trafego": {
            "total_visitors":         t.get("unique_visitors_total"),
            "avg_visitors_per_day":   t.get("avg_visitors_per_day"),
            "peak_hour":              t.get("peak_hour"),
            "peak_hour_avg":          t.get("peak_hour_avg"),
            "best_weekday":           t.get("best_weekday"),
            "worst_weekday":          t.get("worst_weekday"),
            "avg_visit_duration_min": t.get("avg_visit_duration_min"),
        },
        "SECCAO_2_zona": {
            "top_zone":          top_zone,
            "top_zone_visitors": top_zone_n,
            "top_dwell_zone":    top_dwell_zone,
            "top_dwell_avg_s":   top_dwell_s,
            "top_5_sequences":   top_seqs,
        },
        "SECCAO_3_funil": {
            "total_visitors":       f.get("total_visitors"),
            "converted_zck_pct":    f.get("converted_zck_pct"),
            "no_checkout_pct":      f.get("no_checkout_pct"),
            "no_checkout_gender":   f.get("no_checkout_profile", {}).get("gender_dist"),
            "no_checkout_age":      f.get("no_checkout_profile", {}).get("age_dist"),
        },
        "SECCAO_4_anomalia": {
            "OBRIGATORIO": "Gera insight de anomalia com estes dados",
            "anomaly_day":     an.get("anomaly_day"),
            "total_anomalies": an.get("total_anomalies"),
            "top_3_anomalies": top_anom,
        },
        "SECCAO_5_demografico": {
            "gender_overall":    d.get("gender_overall"),
            "age_overall":       d.get("age_overall"),
            "dwell_by_segment":  d.get("dwell_by_segment", [])[:4],
        },
    }


# ── Pipeline por estrategia ───────────────────────────────────────────────────

def run_strategy(metrics: dict, strategy: str) -> tuple[dict, dict, float]:
    path = PROMPT_A if strategy == "A" else PROMPT_B
    if path.exists() and path.stat().st_size > 10:
        template = path.read_text(encoding="utf-8")
        log.info("Prompt carregado de: %s", path)
    else:
        template = _PROMPT_B_DEFAULT if strategy == "B" else _PROMPT_A_DEFAULT
        log.info("Usando prompt embutido (strategy %s)", strategy)

    compact = _compact_metrics(metrics)
    prompt  = template.replace("{METRICS}", json.dumps(compact, ensure_ascii=False, indent=2))

    log.info("Prompt final: %d chars", len(prompt))
    raw, elapsed = call_llm(prompt, strategy)
    validated    = validate(parse_response(raw, strategy), strategy)
    ev           = evaluate(validated, strategy, elapsed)
    return validated, ev, elapsed


def compare_strategies(ea: dict, eb: dict) -> dict:
    winner = "A" if ea["score"] >= eb["score"] else "B"
    log.info("── Comparacao A vs B ───────────────────────────────────")
    log.info("  Score A: %.3f  |  Score B: %.3f  |  Vencedor: %s",
             ea["score"], eb["score"], winner)
    return {
        "winner": winner,
        "score_delta": round(abs(ea["score"]-eb["score"]), 3),
        "strategy_A": ea, "strategy_B": eb,
        "conclusion": (
            f"Estrategia {winner} venceu com score "
            f"{max(ea['score'],eb['score']):.3f} vs "
            f"{min(ea['score'],eb['score']):.3f}."
        ),
    }


# ── API ───────────────────────────────────────────────────────────────────────

def run(input_path, output_path, strategy="both", do_compare=False):
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    check_ollama()

    with open(input_path, encoding="utf-8") as f:
        metrics = json.load(f)
    log.info("metrics.json carregado de '%s'", input_path)

    if do_compare or strategy == "both":
        # Correr estrategia A
        r_a, e_a, _ = run_strategy(metrics, "A")
        out_a = out.parent / "insights_a.json"
        with open(out_a, "w", encoding="utf-8") as f:
            json.dump({**r_a, "evaluation": e_a}, f, ensure_ascii=False, indent=2)
        log.info("insights_a.json -> %s  (%d insights, score=%.3f)",
                 out_a, len(r_a.get("insights",[])), e_a["score"])

        # Correr estrategia B
        r_b, e_b, _ = run_strategy(metrics, "B")
        out_b = out.parent / "insights_b.json"
        with open(out_b, "w", encoding="utf-8") as f:
            json.dump({**r_b, "evaluation": e_b}, f, ensure_ascii=False, indent=2)
        log.info("insights_b.json -> %s  (%d insights, score=%.3f)",
                 out_b, len(r_b.get("insights",[])), e_b["score"])

        # Comparar e guardar insights.json com a estrategia vencedora
        cmp    = compare_strategies(e_a, e_b)
        best   = r_a if cmp["winner"] == "A" else r_b
        result = {
            **best,
            "strategy_comparison": cmp,
            "strategy_A_result":   {**r_a, "evaluation": e_a},
            "strategy_B_result":   {**r_b, "evaluation": e_b},
        }

    else:
        result, ev, _ = run_strategy(metrics, strategy)
        result["evaluation"] = ev

    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    log.info("insights.json -> %s  (estrategia vencedora: %s)",
             out, result.get("strategy_comparison", {}).get("winner", strategy))
    return result


# ── Execucao directa ──────────────────────────────────────────────────────────
# python src/insights.py --input output/metrics.json --output output/insights.json

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description=(
            f"Insights: gera insights accionaveis usando {MODEL} via Ollama.\n"
            "Sem API key. Corre completamente local."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--input",    default=str(DEFAULT_INPUT))
    ap.add_argument("--output",   default=str(DEFAULT_OUTPUT))
    ap.add_argument("--strategy", default="both", choices=["A","B","both"],
                    help="A=zero-shot  B=few-shot  both=ambas+comparacao")
    ap.add_argument("--compare",  action="store_true")
    args = ap.parse_args()

    run(args.input, args.output,
        strategy=args.strategy,
        do_compare=args.compare or args.strategy == "both")