#!/usr/bin/env python3
"""
report.py -- Fase 4: Report Semanal

Le output/insights.json e gera output/weekly_report.md.
Usa APENAS o insights.json como input -- sem ficheiros externos.

Uso:
    python src/report.py --input output/insights.json --output output/weekly_report.md

Importavel:
    from report import run as run_report
"""

import argparse
import json
import logging
from datetime import datetime
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("report")

# ── Paths ─────────────────────────────────────────────────────────────────────

def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent.parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "output" / "insights.json").exists():
            return path
    return Path.cwd()


ROOT           = _find_root()
DEFAULT_INPUT  = ROOT / "output" / "insights.json"
DEFAULT_OUTPUT = ROOT / "output" / "weekly_report.md"

URGENCIA_ORDER = {"imediata": 0, "esta_semana": 1, "proximo_mes": 2}
URGENCIA_LABEL = {
    "imediata":    "🔴 Imediata",
    "esta_semana": "🟡 Esta semana",
    "proximo_mes": "🟢 Próximo mês",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _trunc(text: str, max_w: int) -> str:
    words = str(text).split()
    return " ".join(words[:max_w]) + ("..." if len(words) > max_w else "")


def _by_cat(insights, cat):
    return [i for i in insights if i.get("categoria") == cat]


def _sorted_urg(insights):
    return sorted(insights,
                  key=lambda x: URGENCIA_ORDER.get(x.get("urgencia", "proximo_mes"), 9))


def _top(insights, n):
    return _sorted_urg(insights)[:n]


# ── Resumo Executivo (≤150 palavras) ─────────────────────────────────────────

def sec_resumo(insights: list) -> str:
    top3  = _top(insights, 3)
    lines = ["## 1. Resumo Executivo\n"]

    # Cada bullet: titulo (max 8 palavras) + observacao (max 18 palavras) = ~26 palavras
    # 3 bullets x 26 = 78 palavras + overhead header = bem abaixo de 150
    for ins in top3:
        titulo = _trunc(ins.get("titulo", ""), 8)
        obs    = _trunc(ins.get("observacao", ""), 18)
        lines.append(f"- **{titulo}**: {obs}")

    if not top3:
        lines.append("_Sem dados disponíveis._")

    return "\n".join(lines) + "\n"


# ── Performance de Tráfego ────────────────────────────────────────────────────

def sec_trafego(insights: list) -> str:
    lines = ["## 2. Performance de Tráfego\n"]
    ins_list = _by_cat(insights, "trafego")

    if ins_list:
        for ins in ins_list:
            urg = URGENCIA_LABEL.get(ins["urgencia"], ins["urgencia"])
            lines.append(f"### {ins['titulo']}")
            lines.append(f"**Dados:** {ins['observacao']}")
            lines.append(f"**Impacto:** {ins['implicacao']}")
            lines.append(f"**Acção:** {ins['recomendacao']}")
            lines.append(f"*{urg}*\n")
    else:
        lines.append("_Sem dados de tráfego disponíveis._\n")

    return "\n".join(lines) + "\n"


# ── Análise de Zonas ──────────────────────────────────────────────────────────

def sec_zonas(insights: list) -> str:
    lines    = ["## 3. Análise de Zonas\n"]
    ins_list = _by_cat(insights, "zona")

    if ins_list:
        for ins in ins_list:
            urg = URGENCIA_LABEL.get(ins["urgencia"], ins["urgencia"])
            lines.append(f"### {ins['titulo']}")
            lines.append(f"**O que os dados mostram:** {ins['observacao']}")
            lines.append(f"**Hipótese de causa:** {ins['implicacao']}")
            lines.append(f"**Recomendação:** {ins['recomendacao']}")
            lines.append(f"*{urg}*\n")
    else:
        lines.append("_Sem insights de zona gerados para esta semana._\n")

    return "\n".join(lines) + "\n"


# ── Funil de Clientes ─────────────────────────────────────────────────────────

def sec_funil(insights: list) -> str:
    lines    = ["## 4. Funil de Clientes\n"]
    ins_list = _by_cat(insights, "funil")

    if ins_list:
        for ins in ins_list:
            urg = URGENCIA_LABEL.get(ins["urgencia"], ins["urgencia"])
            lines.append(f"### {ins['titulo']}")
            lines.append(f"**Dados:** {ins['observacao']}")
            lines.append(f"**Impacto:** {ins['implicacao']}")
            lines.append(f"**Acção:** {ins['recomendacao']}")
            lines.append(f"*{urg}*\n")
    else:
        lines.append("_Sem dados de funil disponíveis._\n")

    return "\n".join(lines) + "\n"


# ── Anomalias da Semana ───────────────────────────────────────────────────────

def sec_anomalias(insights: list) -> str:
    lines    = ["## 5. Anomalias da Semana\n"]
    ins_list = _by_cat(insights, "anomalia")

    if ins_list:
        for ins in ins_list:
            urg = URGENCIA_LABEL.get(ins["urgencia"], ins["urgencia"])
            lines.append(f"### {ins['titulo']}")
            lines.append(f"**Descrição:** {ins['observacao']}")
            lines.append(f"**Possível causa:** {ins['implicacao']}")
            lines.append(f"**Acção recomendada:** {ins['recomendacao']}")
            lines.append(f"*{urg}*\n")
    else:
        lines.append("_Sem anomalias significativas esta semana._\n")

    return "\n".join(lines) + "\n"


# ── Recomendações ─────────────────────────────────────────────────────────────

def sec_recomendacoes(insights: list) -> str:
    lines = ["## 6. Recomendações para a Próxima Semana\n"]
    top5  = _top(insights, 5)

    for i, ins in enumerate(top5, 1):
        urg = URGENCIA_LABEL.get(ins["urgencia"], ins["urgencia"])
        rec = _trunc(ins["recomendacao"], 25)
        lines.append(f"**{i}.** {rec}")
        lines.append(f"   {urg} — _{ins['titulo']}_\n")

    if not top5:
        lines.append("_Sem recomendações disponíveis._\n")

    return "\n".join(lines) + "\n"


# ── Montar report ─────────────────────────────────────────────────────────────

def build_report(insights: list) -> str:
    now = datetime.now().strftime("%d/%m/%Y %H:%M")
    return "\n".join([
        "# Report Semanal — Loja de Retalho",
        f"*Gerado automaticamente em {now}*\n",
        "---\n",
        sec_resumo(insights),
        sec_trafego(insights),
        sec_zonas(insights),
        sec_funil(insights),
        sec_anomalias(insights),
        sec_recomendacoes(insights),
        "---",
        "*Pipeline: journeys.csv → metrics.json → insights.json → weekly_report.md*",
    ])


# ── API ───────────────────────────────────────────────────────────────────────

def run(input_path, output_path):
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    with open(input_path, encoding="utf-8") as f:
        data = json.load(f)
    insights = data.get("insights", [])
    log.info("insights.json carregado: %d insights", len(insights))

    # Mostrar distribuicao de categorias
    cats = {}
    for ins in insights:
        c = ins.get("categoria", "?")
        cats[c] = cats.get(c, 0) + 1
    log.info("Categorias: %s", cats)

    report = build_report(insights)
    with open(out, "w", encoding="utf-8") as f:
        f.write(report)

    log.info("weekly_report.md -> %s  (%d palavras)", out, len(report.split()))
    return report


# ── Execucao directa ──────────────────────────────────────────────────────────
# python src/report.py --input output/insights.json --output output/weekly_report.md

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Report: gera weekly_report.md a partir de insights.json"
    )
    ap.add_argument("--input",  default=str(DEFAULT_INPUT))
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    args = ap.parse_args()
    run(args.input, args.output)