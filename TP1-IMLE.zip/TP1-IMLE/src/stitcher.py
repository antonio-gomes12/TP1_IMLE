#!/usr/bin/env python3
"""
stitcher.py -- Fase 1: Reconstrucao de Trajectórias

Uso:
    python src/stitcher.py --input data/events.csv --output output/journeys.csv

Importavel:
    from stitcher import run as run_stitcher

─────────────────────────────────────────────────────────────────────────────
REGRAS DE TRAJECTÓRIA
─────────────────────────────────────────────────────────────────────────────

INICIO: obrigatoriamente Z_E1 ou Z_E2. Sem excepcoes.

FIM:
  1. Z_CK  — checkout definitivo, sem reentradas.
  2. Z_E   — saida sem compra.
  3. Gap > 5 min — fim implicito (enunciado). A trajectória passa para o
     pool de "adormecidas" e pode ser reactivada se um visit compativel
     aparecer no mesmo dia (sensor perdeu a pessoa temporariamente).

COBERTURA 100%:
  Matching em duas fases:
  Fase 1 (activas): trajectórias com gap <= 5 min, todas as restricoes.
  Fase 2 (adormecidas): trajectórias fechadas por gap no mesmo dia.
    - Restricoes hard mantidas: gap < 0, dia diferente, atributos bloqueados.
    - Restricao espacial NAO se aplica: se o gap e grande (>5 min) ha tempo
      suficiente para qualquer transicao dentro da loja.
    - Nao se inventam caminhos -- o gap grande ja justifica a transicao.

TEMPOS DE CAMINHADA:
  walk_seconds no zones.json sao tempos MEDIOS.
  Aplica-se WALK_MARGIN=0.6: aceita ate 40% mais rapido que a media.
─────────────────────────────────────────────────────────────────────────────
"""

import argparse
import heapq
import json
import logging
import statistics
from collections import Counter
from datetime import timedelta
from pathlib import Path
import pandas as pd

# ── Configuracao ──────────────────────────────────────────────────────────────
RANDOM_SEED           = 42
MAX_TRANSITION_GAP_S  = 300    # 5 min -- rejeicao hard na fase activa
MAX_IDLE_S            = 300    # mesmo: gap > 5 min -> adormecida
MAX_DORMANT_S         = 1800   # 30 min: depois disto a adormecida fecha definitivamente
MAX_VISIT_DURATION_S  = 14400  # 4h max
ATTR_MISMATCH_PENALTY = 150.0
ATTR_LOCK_AFTER       = 2
WALK_MARGIN           = 0.6    # aceitar ate 40% mais rapido que o tempo medio
ENTRY_ZONES           = {"Z_E1", "Z_E2"}
EXIT_ZONES            = {"Z_E1", "Z_E2", "Z_CK"}
TERMINAL_ZONE         = "Z_CK"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("stitcher")


# ── Paths ─────────────────────────────────────────────────────────────────────

def _find_root():
    candidates = []
    try:
        candidates.append(Path(__file__).resolve().parent.parent)
        candidates.append(Path(__file__).resolve().parent)
    except NameError:
        pass
    cwd = Path.cwd()
    candidates += [cwd] + list(cwd.parents)[:4]
    for path in candidates:
        if (path / "data" / "events.csv").exists():
            return path
    return Path.cwd()


ROOT           = _find_root()
DEFAULT_INPUT  = ROOT / "data"   / "events.csv"
DEFAULT_OUTPUT = ROOT / "output" / "journeys.csv"
ZONES_FILE     = ROOT / "zones.json"


# ── Walk matrix ───────────────────────────────────────────────────────────────

def load_zones(path):
    if not path.exists():
        log.warning("zones.json nao encontrado -- restricao espacial desactivada.")
        return {}
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    zones = raw.get("zones", {})
    log.info("zones.json carregado -- %d zonas", len(zones))
    return zones


def _dijkstra(source, zones):
    dist = {source: 0.0}
    heap = [(0.0, source)]
    while heap:
        d, node = heapq.heappop(heap)
        if d > dist.get(node, float("inf")):
            continue
        for nb, w in zones.get(node, {}).get("walk_seconds", {}).items():
            nd = d + w
            if nd < dist.get(nb, float("inf")):
                dist[nb] = nd
                heapq.heappush(heap, (nd, nb))
    return dist


def build_walk_matrix(zones):
    if not zones:
        return {}
    log.info("Calculando walk matrix (Dijkstra, %d zonas, margem=%.0f%%)...",
             len(zones), WALK_MARGIN * 100)
    matrix = {z: _dijkstra(z, zones) for z in zones}
    log.info("Walk matrix calculada.")
    return matrix


# ── Parse ─────────────────────────────────────────────────────────────────────

def parse_events(path):
    df = pd.read_csv(path, dtype=str)
    df.columns = [c.strip().lower() for c in df.columns]
    try:
        df["timestamp"] = pd.to_datetime(df["timestamp"], dayfirst=True, format="mixed")
    except Exception:
        df["timestamp"] = pd.to_datetime(df["timestamp"], dayfirst=True)
    df["duration_s"] = pd.to_numeric(df["duration_s"], errors="coerce").fillna(0).astype(int)
    df["event_type"] = df["event_type"].str.strip().str.lower()
    df["gender"]     = df["gender"].str.strip().fillna("U")
    df["age_range"]  = df["age_range"].str.strip().fillna("unknown")
    df = df.sort_values(["timestamp", "event_id"]).reset_index(drop=True)
    log.info("Carregados %d eventos  [%s -> %s]",
             len(df), df["timestamp"].min(), df["timestamp"].max())
    return df


# ── Fase A: Zone visits ───────────────────────────────────────────────────────

def _simple_attr_score(g1, a1, g2, a2):
    g = int(g1 != g2) if "U"       not in (g1, g2) else 0
    a = int(a1 != a2) if "unknown" not in (a1, a2) else 0
    return g + a


def _process_zone(records):
    visits   = []
    pending  = []
    n_orphan = 0
    for row in records:
        ts    = row["timestamp"]
        etype = row["event_type"]
        if etype == "entry":
            pending.append({
                "entry_time": ts, "exit_time": None, "dwell_s": 0,
                "gender": row["gender"], "age_range": row["age_range"],
                "has_linger": False, "event_ids": [row["event_id"]],
            })
        elif etype == "linger":
            best_idx, best_score = None, 999
            for i, p in enumerate(pending):
                if p["has_linger"]:
                    continue
                gap = (ts - p["entry_time"]).total_seconds()
                if gap < 0 or gap > MAX_TRANSITION_GAP_S:
                    continue
                score = _simple_attr_score(p["gender"], p["age_range"],
                                           row["gender"], row["age_range"])
                if score < best_score:
                    best_score, best_idx = score, i
            if best_idx is not None:
                pending[best_idx]["dwell_s"]   = row["duration_s"]
                pending[best_idx]["has_linger"] = True
                pending[best_idx]["event_ids"].append(row["event_id"])
        elif etype == "exit":
            best_idx, best_score = None, 999
            for i, p in enumerate(pending):
                gap = (ts - p["entry_time"]).total_seconds()
                if gap < 0 or gap > MAX_TRANSITION_GAP_S:
                    continue
                score = _simple_attr_score(p["gender"], p["age_range"],
                                           row["gender"], row["age_range"])
                if score < best_score:
                    best_score, best_idx = score, i
            if best_idx is not None:
                entry = pending.pop(best_idx)
                entry["exit_time"] = ts
                # dwell_s = max(linger reportado, tempo real entry->exit)
                real_dwell = int((ts - entry["entry_time"]).total_seconds())
                entry["dwell_s"] = max(entry["dwell_s"], real_dwell)
                entry["event_ids"].append(row["event_id"])
                visits.append(entry)
            else:
                n_orphan += 1
    for p in pending:
        p["exit_time"] = p["entry_time"] + timedelta(seconds=max(p["dwell_s"], 30))
        # dwell_s ja esta correcto (inferido ou do linger)
        visits.append(p)
    return visits, n_orphan


def extract_zone_visits(df):
    all_records = df[["event_id", "timestamp", "zone_id", "event_type",
                       "duration_s", "gender", "age_range"]].to_dict("records")
    by_zone = {}
    for row in all_records:
        zid = row["zone_id"]
        if zid not in by_zone:
            by_zone[zid] = []
        by_zone[zid].append(row)
    visits        = []
    total_orphans = 0
    for zone_id, records in by_zone.items():
        zone_visits, n_orphan = _process_zone(records)
        for v in zone_visits:
            v["zone_id"] = zone_id
        visits.extend(zone_visits)
        total_orphans += n_orphan
    visits.sort(key=lambda v: v["entry_time"])
    if total_orphans:
        log.debug("%d exits orfaos ignorados", total_orphans)
    log.info("Extraidas %d zone visits", len(visits))
    return visits


# ── Fase B: Stitching ────────────────────────────────────────────────────────

def _dominant(counter):
    filtered = {k: v for k, v in counter.items() if k not in ("U", "unknown")}
    return max(filtered, key=filtered.get) if filtered else None


class _Trajectory:
    __slots__ = ("person_id", "last_zone", "last_exit",
                 "gender_counts", "age_counts", "gender_locked", "age_locked",
                 "visits", "start_time", "visit_date", "is_closed", "close_reason")

    def __init__(self, person_id, first_visit):
        self.person_id     = person_id
        self.last_zone     = first_visit["zone_id"]
        self.last_exit     = first_visit["exit_time"]
        self.gender_counts = Counter()
        self.age_counts    = Counter()
        self.gender_locked = False
        self.age_locked    = False
        self.visits        = [first_visit]
        self.start_time    = first_visit["entry_time"]
        self.visit_date    = first_visit["entry_time"].date()
        self.is_closed     = (first_visit["zone_id"] == TERMINAL_ZONE)
        self.close_reason  = "Z_CK" if self.is_closed else None
        self._register(first_visit["gender"], first_visit["age_range"])

    def _register(self, gender, age_range):
        if gender not in ("U",):
            self.gender_counts[gender] += 1
        if age_range not in ("unknown",):
            self.age_counts[age_range] += 1
        dom_g = _dominant(self.gender_counts)
        if dom_g and self.gender_counts[dom_g] >= ATTR_LOCK_AFTER:
            self.gender_locked = True
        dom_a = _dominant(self.age_counts)
        if dom_a and self.age_counts[dom_a] >= ATTR_LOCK_AFTER:
            self.age_locked = True

    @property
    def dom_gender(self):
        return _dominant(self.gender_counts) or "U"

    @property
    def dom_age(self):
        return _dominant(self.age_counts) or "unknown"

    def _attr_hard_reject(self, vg, va):
        """True se os atributos bloqueados contradizem o visit."""
        if self.gender_locked and vg not in ("U",) and vg != self.dom_gender:
            return True
        if self.age_locked and va not in ("unknown",) and va != self.dom_age:
            return True
        return False

    def _attr_penalty(self, vg, va):
        score = 0.0
        if vg not in ("U",) and self.dom_gender not in ("U",) and vg != self.dom_gender:
            score += ATTR_MISMATCH_PENALTY
        if va not in ("unknown",) and self.dom_age not in ("unknown",) and va != self.dom_age:
            score += ATTR_MISMATCH_PENALTY
        return score

    def score_active(self, visit, matrix):
        """
        Fase 1 -- trajectória activa (gap <= 5 min).
        Todas as restricoes aplicadas.
        """
        if self.is_closed:
            return None
        gap = (visit["entry_time"] - self.last_exit).total_seconds()
        if gap < 0 or gap > MAX_TRANSITION_GAP_S:
            return None
        if matrix:
            avg_walk = matrix.get(self.last_zone, {}).get(visit["zone_id"])
            if avg_walk is not None and gap < avg_walk * WALK_MARGIN:
                return None
        if visit["entry_time"].date() != self.visit_date:
            return None
        if (visit["entry_time"] - self.start_time).total_seconds() > MAX_VISIT_DURATION_S:
            return None
        vg, va = visit["gender"], visit["age_range"]
        if self._attr_hard_reject(vg, va):
            return None
        return gap + self._attr_penalty(vg, va)

    def score_dormant(self, visit):
        """
        Fase 2 -- trajectória adormecida (fechada por gap, mesmo dia,
        inactiva ha menos de 30 min).
        Restricoes hard: gap < 0, dia diferente, atributos bloqueados.
        Restricao espacial NAO se aplica: gap > 5 min ja garante tempo
        suficiente para qualquer transicao dentro da loja.
        """
        if self.close_reason != "gap":
            return None   # so reactivar as fechadas por gap (nao Z_CK nem Z_E)
        gap = (visit["entry_time"] - self.last_exit).total_seconds()
        if gap < 0:
            return None   # sobreposicao temporal: impossivel
        if visit["entry_time"].date() != self.visit_date:
            return None
        vg, va = visit["gender"], visit["age_range"]
        if self._attr_hard_reject(vg, va):
            return None
        # Score: preferir trajectórias mais recentes e mais compativeis
        # gap grande = pior candidato (mas aceitavel)
        return gap * 0.1 + self._attr_penalty(vg, va)

    def attach(self, visit):
        # Reactivar se estava adormecida
        if self.close_reason == "gap":
            self.is_closed    = False
            self.close_reason = None
        self.visits.append(visit)
        self.last_zone = visit["zone_id"]
        self.last_exit = visit["exit_time"]
        self._register(visit["gender"], visit["age_range"])
        if visit["zone_id"] == TERMINAL_ZONE:
            self.is_closed    = True
            self.close_reason = "Z_CK"
        elif visit["zone_id"] in ENTRY_ZONES and len(self.visits) > 1:
            self.is_closed    = True
            self.close_reason = "Z_E"

    def close_by_gap(self):
        self.is_closed    = True
        self.close_reason = "gap"


def stitch_trajectories(visits, walk_matrix):
    """
    Stitching greedy com pool de adormecidas para cobertura 100%.

    active:   trajectórias com gap <= 5 min (todas as restricoes).
    dormant:  trajectórias fechadas por gap no mesmo dia (so atributos hard).
    closed:   trajectórias terminadas definitivamente (Z_CK ou Z_E).

    Para cada visit:
      1. Fase activa: procurar em 'active'.
      2. Se zona Z_E sem match: criar nova trajectória.
      3. Se zona nao Z_E sem match: procurar em 'dormant'.
         Se encontrar: reactivar e anexar.
         Se nao encontrar: nao pode acontecer com dados bem formados
         (toda a pessoa que esta na loja entrou por Z_E).
    """
    active  = []
    dormant = []   # fechadas por gap, mesmo dia -- candidatas a reactivacao
    closed  = []   # definitivamente fechadas (Z_CK ou Z_E)
    counter = 1
    n_strict   = 0
    n_dormant  = 0
    n_new      = 0

    for visit in visits:
        entry_time = visit["entry_time"]
        visit_date = entry_time.date()

        # Actualizar listas: expirar activas, limpar dormant de dias anteriores
        still_active = []
        for t in active:
            idle = (entry_time - t.last_exit).total_seconds()
            if t.is_closed:
                if t.close_reason == "gap":
                    dormant.append(t)
                else:
                    closed.append(t)
            elif idle > MAX_IDLE_S:
                t.close_by_gap()
                dormant.append(t)
            else:
                still_active.append(t)
        active = still_active
        # Limpar dormant: remover as de dias diferentes ou inactivas ha > 30 min
        still_dormant = []
        for t in dormant:
            if t.visit_date != visit_date:
                closed.append(t)
            elif (entry_time - t.last_exit).total_seconds() > MAX_DORMANT_S:
                closed.append(t)   # fechada definitivamente por timeout
            else:
                still_dormant.append(t)
        dormant = still_dormant

        # ── Fase 1: activas ───────────────────────────────────────────────
        best_traj, best_score = None, float("inf")
        for t in active:
            s = t.score_active(visit, walk_matrix)
            if s is not None and s < best_score:
                best_score, best_traj = s, t

        if best_traj is not None:
            best_traj.attach(visit)
            n_strict += 1
            continue

        # ── Nova trajectória (so Z_E) ─────────────────────────────────────
        if visit["zone_id"] in ENTRY_ZONES:
            t = _Trajectory("P_{:04d}".format(counter), visit)
            counter += 1
            active.append(t)
            n_new += 1
            continue

        # ── Fase 2: adormecidas ───────────────────────────────────────────
        best_traj, best_score = None, float("inf")
        for t in dormant:
            s = t.score_dormant(visit)
            if s is not None and s < best_score:
                best_score, best_traj = s, t

        if best_traj is not None:
            dormant.remove(best_traj)
            active.append(best_traj)
            best_traj.attach(visit)
            n_dormant += 1
        else:
            # Nao devia acontecer: toda a pessoa entrou por Z_E
            # Se acontecer, registar para debug
            log.debug("Visit sem match possivel: %s @ %s -- ignorado",
                      visit["zone_id"], entry_time)

    # Fechar restantes
    for t in active:
        if not t.is_closed:
            t.close_by_gap()
    for t in dormant:
        pass  # ja fechadas por gap

    all_closed = closed + active + dormant
    by_reason  = Counter(t.close_reason for t in all_closed)

    log.info("Trajectórias reconstruidas: %d", len(all_closed))
    log.info("  Visits via activas    : %d", n_strict)
    log.info("  Visits via adormecidas: %d  (sensor perdeu temporariamente)", n_dormant)
    log.info("  Novas trajectórias    : %d  (via Z_E)", n_new)
    log.info("  Fim Z_CK  (checkout)  : %d", by_reason.get("Z_CK", 0))
    log.info("  Fim Z_E   (sem compra): %d", by_reason.get("Z_E",  0))
    log.info("  Fim gap   (implicito) : %d", by_reason.get("gap",  0))

    return (
        {t.person_id: t.visits       for t in all_closed},
        {t.person_id: t.close_reason for t in all_closed},
    )


# ── Output ────────────────────────────────────────────────────────────────────

def build_journeys_df(trajectories, reason_map):
    rows = []
    for person_id, visits in trajectories.items():
        reason = reason_map.get(person_id, "gap")
        for v in visits:
            et, xt = v["entry_time"], v["exit_time"]
            rows.append({
                "person_id":   person_id,
                "zone_id":     v["zone_id"],
                "entry_time":  et.strftime("%Y-%m-%d %H:%M:%S"),
                "exit_time":   xt.strftime("%Y-%m-%d %H:%M:%S"),
                "dwell_s":     v["dwell_s"],
                "gender":      v["gender"],
                "age_range":   v["age_range"],
                "visit_date":  et.strftime("%Y-%m-%d"),
                "hour_of_day": et.hour,
            })
    df = pd.DataFrame(rows)
    if df.empty:
        log.warning("Nenhuma trajectória encontrada.")
        return df
    return df.sort_values(["person_id", "entry_time"]).reset_index(drop=True)


# ── Metricas ──────────────────────────────────────────────────────────────────

def quick_quality_report(journeys, events, reason_map=None):
    if journeys.empty:
        return

    n_people = journeys["person_id"].nunique()
    n_visits = len(journeys)
    n_events = len(events)

    j = journeys.copy()
    j["entry_dt"] = pd.to_datetime(j["entry_time"])
    j["exit_dt"]  = pd.to_datetime(j["exit_time"])
    j_s = j.sort_values(["person_id", "entry_dt"])

    # H1: Consistencia temporal
    bad = 0
    for _, grp in j_s.groupby("person_id"):
        grp = grp.reset_index(drop=True)
        for i in range(1, len(grp)):
            if (grp.loc[i, "entry_dt"] < grp.loc[i-1, "exit_dt"] and
                    grp.loc[i, "zone_id"] != grp.loc[i-1, "zone_id"]):
                bad += 1
    consistency_pct = 100.0 * (1 - bad / max(n_visits, 1))

    # Inicio / fim
    first_z   = j_s.groupby("person_id")["zone_id"].first()
    ze1_count = (first_z == "Z_E1").sum()
    ze2_count = (first_z == "Z_E2").sum()
    entry_pct = 100.0 * first_z.isin(ENTRY_ZONES).sum() / max(n_people, 1)

    # Razoes de fecho via reason_map (nao esta no CSV)
    reason_map = reason_map or {}
    n_zck      = sum(1 for v in reason_map.values() if v == "Z_CK")
    n_ze       = sum(1 for v in reason_map.values() if v == "Z_E")
    n_gap      = sum(1 for v in reason_map.values() if v == "gap")
    completude = 100.0 * (n_zck + n_ze) / max(n_people, 1)

    # Estabilidade de atributos
    gc = ac = 0
    for _, grp in j_s.groupby("person_id"):
        grp = grp.reset_index(drop=True)
        for i in range(1, len(grp)):
            g0, g1 = grp.loc[i-1, "gender"],   grp.loc[i, "gender"]
            a0, a1 = grp.loc[i-1, "age_range"], grp.loc[i, "age_range"]
            if g0 not in ("U",) and g1 not in ("U",) and g0 != g1:
                gc += 1
            if a0 not in ("unknown",) and a1 not in ("unknown",) and a0 != a1:
                ac += 1
    trans = max(n_visits - n_people, 1)

    # Cobertura
    linger_v       = j["dwell_s"].gt(0).sum()
    events_covered = linger_v * 3 + (n_visits - linger_v) * 2
    coverage_pct   = min(100.0, 100.0 * events_covered / max(n_events, 1))

    # Visitas e duracao
    vpt = j_s.groupby("person_id").size()
    dur = j_s.groupby("person_id").apply(
        lambda g: (g["exit_dt"].max() - g["entry_dt"].min()).total_seconds() / 60
    )

    # Gaps
    gaps = []
    for _, grp in j_s.groupby("person_id"):
        grp = grp.reset_index(drop=True)
        for i in range(1, len(grp)):
            gaps.append(
                (grp.loc[i, "entry_dt"] - grp.loc[i-1, "exit_dt"]).total_seconds()
            )
    mg  = statistics.median(gaps) if gaps else 0
    p95 = sorted(gaps)[int(len(gaps) * .95)] if gaps else 0

    log.info("── Metricas de qualidade ──────────────────────────────────────")
    log.info("  Pessoas          : %d", n_people)
    log.info("  Zone visits      : %d  (eventos originais: %d)", n_visits, n_events)
    log.info("  Visitas/traj     : mediana=%.0f  p95=%.0f  max=%.0f",
             vpt.median(), vpt.quantile(.95), vpt.max())
    log.info("  Duracao visita   : mediana=%.1fmin  p95=%.1fmin  max=%.1fmin",
             dur.median(), dur.quantile(.95), dur.max())
    log.info("── Regras de trajectória ──────────────────────────────────────")
    log.info("  Inicio em Z_E    : %.1f%%  (alvo: 100%%)", entry_pct)
    log.info("    via Z_E1       : %d  |  via Z_E2: %d", ze1_count, ze2_count)
    log.info("  Fim por Z_CK     : %d  (%.1f%%)  checkout",
             n_zck, 100 * n_zck / max(n_people, 1))
    log.info("  Fim por Z_E      : %d  (%.1f%%)  saida sem compra",
             n_ze,  100 * n_ze  / max(n_people, 1))
    log.info("  Fim por gap>5min : %d  (%.1f%%)  fim implicito",
             n_gap, 100 * n_gap / max(n_people, 1))
    log.info("  Completude       : %.1f%%  (inicio Z_E + fim Z_E/Z_CK)", completude)
    log.info("── Qualidade interna ──────────────────────────────────────────")
    log.info("  Consistencia H1  : %.1f%%  (alvo: 100%%)", consistency_pct)
    log.info("  Gender estavel   : %.1f%%  (mudancas: %d)", 100*(1-gc/trans), gc)
    log.info("  Age estavel      : %.1f%%  (mudancas: %d)", 100*(1-ac/trans), ac)
    log.info("  Cobertura        : %.1f%%  (alvo: 100%%)", coverage_pct)
    log.info("  Gap mediano      : %.0fs  (p95: %.0fs)", mg, p95)
    log.info("───────────────────────────────────────────────────────────────")


# ── API ───────────────────────────────────────────────────────────────────────

def run(input_path, output_path):
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    zones        = load_zones(ZONES_FILE)
    walk_matrix  = build_walk_matrix(zones)
    df_events    = parse_events(input_path)
    visits       = extract_zone_visits(df_events)
    trajectories, reason_map = stitch_trajectories(visits, walk_matrix)
    journeys     = build_journeys_df(trajectories, reason_map)
    journeys.to_csv(out, index=False)
    log.info("journeys.csv -> %s  (%d linhas)", out, len(journeys))
    quick_quality_report(journeys, df_events, reason_map)
    return journeys


# ── Execucao directa ──────────────────────────────────────────────────────────
# python src/stitcher.py --input data/events.csv --output output/journeys.csv

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Stitcher: reconstroi trajectórias a partir de events.csv"
    )
    ap.add_argument("--input",  default=str(DEFAULT_INPUT),
                    help="Caminho para events.csv")
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT),
                    help="Caminho de saida para journeys.csv")
    args = ap.parse_args()
    run(args.input, args.output)